package com.javatpoint.service;

import com.javatpoint.beans.Login;
import com.javatpoint.beans.User;

public interface UserService {
	void register(User user);
	User validateUser(Login login);

}
